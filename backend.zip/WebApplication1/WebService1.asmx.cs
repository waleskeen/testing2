﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.WebSockets;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [ScriptService]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        DataClasses1DataContext dc;
        JavaScriptSerializer js;

        public WebService1()
        {
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString; 
            dc = new DataClasses1DataContext(connStr);
            js = new JavaScriptSerializer();
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void getTextFile()
        {
            try
            {
                dynamic ls = new List<Dictionary<string, dynamic>>();
                using (StreamWriter sw = new StreamWriter("Fruits.txt"))
                {

                }
                using (StreamWriter sw = new StreamWriter("Veggies.txt"))
                {

                }
                string result = js.Serialize(ls);
                this.Context.Response.Write(result);
            }
            catch (Exception ex)
            {
                this.Context.Response.Write(ex.Message);
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void getEmployee()
        {
            dynamic lsEmp = (from emp in dc.employees
                            join dp in dc.departments on emp.id equals dp.emp_id
                            select new
                            {
                                emp.name
                                , dp.designation
                                , emp.age
                            }).ToList();
            string result = js.Serialize(lsEmp);
            this.Context.Response.Write(result);
        }
    }
}
