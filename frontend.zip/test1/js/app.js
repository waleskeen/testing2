angular.module("app", [])
   .controller("testController", function($scope, $http) {
		$scope.title = "Test";
		$scope.arrCol = [];
		$scope.arr = [];
		$scope.loadFile = function(){
			$http.get("http://localhost:51356/WebService1.asmx/getEmployee")
				.then(function(response) {
					$scope.arrCol = [

					];
					$scope.arr = response.data;
			});
		};
		$scope.loadDB = function(){
			$http.get("http://localhost:51356/WebService1.asmx/getEmployee")
				.then(function(response) {
					$scope.arrCol = [
						{"key":"name", "label":"Employee Name"}
						, {"key":"designation", "label":"Designation"}
						, {"key":"age", "label":"Age"}
					];
					$scope.arr = response.data;
			});
			
		};
   });